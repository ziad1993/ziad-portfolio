export default function Portfolio() {
  return (
    <main className="p-6 max-w-4xl mx-auto">
      <section className="text-center mb-10">
        <h1 className="text-4xl font-bold">El Falah Ziad</h1>
        <p className="text-lg mt-2 text-muted-foreground">
          Aspiring Data Analyst | Turning Data into Decisions
        </p>
      </section>

      <section className="grid gap-6">
        <div className="rounded-2xl shadow p-4">
          <h2 className="text-2xl font-semibold mb-2">About Me</h2>
          <p>
            I am passionate about uncovering actionable insights through data. My goal is to help organizations make informed decisions by transforming complex datasets into meaningful stories using tools like Excel, SQL, Tableau, and Python.
          </p>
        </div>

        <div className="rounded-2xl shadow p-4">
          <h2 className="text-2xl font-semibold mb-2">Projects</h2>
          <ul className="list-disc list-inside space-y-2">
            <li>
              <strong>Sales Dashboard (Tableau):</strong> Visualized sales performance across regions and product lines using interactive dashboards.
            </li>
            <li>
              <strong>Customer Churn Analysis (Excel + SQL):</strong> Identified patterns in customer attrition using SQL queries and Excel visualizations.
            </li>
            <li>
              <strong>COVID-19 Data Tracker (Python + Pandas):</strong> Cleaned and analyzed global COVID-19 datasets to track trends and identify key risk factors.
            </li>
          </ul>
        </div>

        <div className="rounded-2xl shadow p-4">
          <h2 className="text-2xl font-semibold mb-2">Resume</h2>
          <a
            href="#"
            className="text-blue-600 hover:underline"
            target="_blank"
            rel="noopener noreferrer"
          >
            Download Resume (PDF)
          </a>
        </div>

        <div className="rounded-2xl shadow p-4">
          <h2 className="text-2xl font-semibold mb-2">Contact</h2>
          <p>Email: <a href="mailto:ziad.data@gmail.com" className="text-blue-600">ziad.data@gmail.com</a></p>
          <p>LinkedIn: <a href="https://www.linkedin.com/in/ziadelfalah" className="text-blue-600" target="_blank">linkedin.com/in/ziadelfalah</a></p>
        </div>
      </section>
    </main>
  );
}
